Dears,, I'm very sorry for being late, but I did my best for studing the curriculum,, and did my best in the project,,, 
I didn't use numpy in the project, there no need for it, but I will practice on it by myself.
I hope the project will explain itself, 
Thanks for your efforts ^_^